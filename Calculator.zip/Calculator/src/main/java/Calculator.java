import java.util.Scanner;
import java.lang.Math.*;
import static java.lang.Math.log;
import static java.lang.Math.pow;
public class Calculator {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to the Scientific Calculator!");
        System.out.println("Enter the first number: ");
        double num1 = input.nextDouble();

        System.out.println("Enter the second number: ");
        double num2 = input.nextDouble();

        System.out.println("Choose an operation: (+, -, *, /, ^, log)");
        String operator = input.next();

        double result = 0;

        switch (operator) {
            case "+":
                result = num1 + num2;
                break;
            case "-":
                result = num1 - num2;
                break;
            case "*":
                result = num1 * num2;
                break;
            case "/":
                result = num1 / num2;
                break;
            case "^":
                result = pow(num1, num2);
                break;
            case "log":
                result = log(num2) / Math.log(num1);
                break;
        }

        System.out.println("The result is: " + result);
    }
}